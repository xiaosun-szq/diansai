/* generated configuration header file - do not edit */
#ifndef R_SCI_B_I2C_CFG_H_
#define R_SCI_B_I2C_CFG_H_
#ifdef __cplusplus
extern "C" {
#endif

#define SCI_B_I2C_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define SCI_B_I2C_CFG_DTC_ENABLE (0)
#define SCI_B_I2C_CFG_ADDR_MODE_10_BIT_ENABLE (0)

#ifdef __cplusplus
}
#endif
#endif /* R_SCI_B_I2C_CFG_H_ */
