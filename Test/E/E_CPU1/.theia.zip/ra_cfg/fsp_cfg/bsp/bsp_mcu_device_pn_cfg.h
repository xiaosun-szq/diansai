/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7KA8P1KFLCAC
      #define BSP_MCU_FEATURE_SET ('K')
      #define BSP_NUMBER_OF_CORES (2)
      #define BSP_PACKAGE_LFBGA
      #define BSP_ROM_SIZE_BYTES (1048576)
      #define BSP_RAM_SIZE_BYTES (1916928)
      #define BSP_DATA_FLASH_SIZE_BYTES (0)
      #define BSP_PACKAGE_PINS (289)
      #define BSP_OSPI0_CS0_START_ADDRESS (2147483648)
      #define BSP_OSPI0_CS0_SIZE_BYTES (268435456)
      #define BSP_OSPI0_CS1_START_ADDRESS (2415919104)
      #define BSP_OSPI0_CS1_SIZE_BYTES (268435456)
      #define BSP_OSPI1_CS0_START_ADDRESS (1879048192)
      #define BSP_OSPI1_CS0_SIZE_BYTES (134217728)
      #define BSP_OSPI1_CS1_START_ADDRESS (2013265920)
      #define BSP_OSPI1_CS1_SIZE_BYTES (134217728)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
