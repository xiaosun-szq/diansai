//
// Created by Qw011 on 2026/6/20.
//
//
// Created by Qw011 on 2026/6/20.
//
#include "CAN_MIT.h"
/************************* CAN 回调函数 *************************/
const canfd_afl_entry_t p_canfd0_afl[CANFD_CFG_AFL_CH0_RULE_NUM] = {0};

void canfd0_callback(can_callback_args_t * p_args)
{
    if (NULL == p_args) return;
    switch (p_args->event)
    {
        case CAN_EVENT_RX_COMPLETE:
        case CAN_EVENT_TX_COMPLETE:
        case CAN_EVENT_ERR_WARNING:
        case CAN_EVENT_ERR_PASSIVE:
        case CAN_EVENT_ERR_BUS_OFF:
        case CAN_EVENT_ERR_CHANNEL:
        case CAN_EVENT_ERR_GLOBAL:
            break;
        default:
            break;
    }
}

/************************* CAN 发送函数 *************************/
fsp_err_t canfd_send_test_data(can_ctrl_t * p_ctrl, uint32_t id, uint8_t * p_data)
{
    can_frame_t tx_frame = {0};
    tx_frame.id             = id;
    tx_frame.id_mode        = CAN_ID_MODE_STANDARD;
    tx_frame.type           = CAN_FRAME_TYPE_DATA;
    tx_frame.data_length_code = 8;
    tx_frame.options        = 0;

    // 复制 8 字节数据
    for (uint8_t i = 0; i < 8; i++)
    {
        tx_frame.data[i] = p_data[i];
    }

    return R_CANFD_Write(p_ctrl, CANFD_TX_BUFFER_FIFO_COMMON_0, &tx_frame);
}