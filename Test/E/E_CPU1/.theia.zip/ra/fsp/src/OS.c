#include "MIT_DBC.h"
#include "os.h"
#include "CAN_MIT.h"
#include <math.h>
#include "key_proc.h"
#include "dbc_proc.h"
#include "hal_data.h"
#include "S485.h"
#include "imu_system.h"
#include "circular_buffer.h"
#include "imu_i2c_driver.h"
#include "foc_lib.h"
#include "arm_kinematics.h"



float cvl = 0;
float lll = 0;
uint8_t rr[] = {0x00, 0x00, 0x33, 0x01};
timer_info_t info3;
IMU_Data_t data;
uint16_t DJ_angle=0;
uint8_t torqueBuf[];
uint8_t sss[];
float cvt =0;
uint8_t qqw= 0;
float atan2_deg(float y, float x)
{
    float rad = atan2f(y, x);
    return rad * 180.0f / PI;
}
//***********************************舵机转角控制************************************
void AAADDD(uint8_t ID, uint16_t angle, uint8_t *torqueBuf, uint8_t *moveBuf)
{

    torqueBuf[0] = 0xFF;
    torqueBuf[1] = 0xFF;
    torqueBuf[2] = ID;
    torqueBuf[3] = 0x04;
    torqueBuf[4] = 0x03;
    torqueBuf[5] = 0x18;
    torqueBuf[6] = 0x01;
    // 计算校验和
    uint16_t sum_torque = ID + 0x04 + 0x03 + 0x18 + 0x01;
    torqueBuf[7] = (~sum_torque) & 0xFF;


    uint16_t pos = (uint16_t)round(1023.0f / 300.0f * angle);
    uint8_t pos_L = pos & 0xFF;
    uint8_t pos_H = (pos >> 8) & 0xFF;

    moveBuf[0] = 0xFF;
    moveBuf[1] = 0xFF;
    moveBuf[2] = ID;
    moveBuf[3] = 0x05;
    moveBuf[4] = 0x03;
    moveBuf[5] = 0x1E;
    moveBuf[6] = pos_L;
    moveBuf[7] = pos_H;
    // 计算校验和
    uint16_t sum_move = ID + 0x05 + 0x03 + 0x1E + pos_L + pos_H;
    moveBuf[8] = (~sum_move) & 0xFF;
}


//***********************************舵机转角控制************************************

//***********************************按键防抖************************************
uint32_t qqq = 0;
uint32_t k = 0;
uint8_t f = 0;    // 上次稳定电平
uint8_t c = 0;    // 防抖输出
uint8_t stable_cnt = 0; // 稳定计数
#define SAMPLE_STABLE_CNT 1 // 按键防抖强度
uint8_t KeyScan(uint8_t pin)
{
    uint8_t curr = pin;
    if (k % 10 == 0)
    {
        if ((f ^ curr) == 0)
        {
            stable_cnt++;
            if (stable_cnt >= SAMPLE_STABLE_CNT)
            {
                c = curr;
            }
        }
        else
        {
            stable_cnt = 0;
            f = curr;
        }
    }
    k++;
    return c;
}

//***********************************按键防抖************************************
uint8_t i = 0;
uint8_t ii = 0;
uint8_t p = 0;

//*************************他们我用来锁存,保证有的信号只发一次************************
uint8_t aaa = 0;
uint8_t bbb = 0;
uint8_t ccc = 0;
uint8_t aaa1 = 0;
uint8_t bbb1 = 0;
uint8_t ccc1= 0;
uint8_t ddd = 0;
uint8_t eee = 0;
uint8_t fff = 0;
uint32_t gg = 0;
uint8_t hh = 0;
//*************************他们我用来锁存，保证有的信号只发一次************************

volatile uint8_t w1[17];
volatile uint16_t adc_buf[8];
uint32_t r = 512000;
uint8_t a[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFC};
uint8_t u[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFD};
uint8_t b[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFB};
uint8_t qq[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFE};
uint8_t q[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFA};

uint8_t l1[] = {0x01,0x10,0x00,0xF1,0x00,0x03,0x06,0x00,0xC8,0x45,0xBB,0x80,0x00,0x57,0xBF};
uint8_t m1[] = {0x01,0x10,0x00,0xF1,0x00,0x03,0x06,0x01,0xC8,0x45,0xBB,0x80,0x00,0x56,0x6E};
uint8_t n1[] = {0x01,0x10,0x00,0xF1,0x00,0x03,0x06,0x00,0xC8,0x00,0x00,0x00,0x00,0x53,0x56};

uint8_t l2[] = {0x02,0x10,0x00,0xF1,0x00,0x03,0x06,0x00,0xC8,0x45,0xBB,0x80,0x00,0x52,0x7C};
uint8_t m2[] = {0x02,0x10,0x00,0xF1,0x00,0x03,0x06,0x01,0xC8,0x45,0xBB,0x80,0x00,0x53,0xAD};
uint8_t n2[] = {0x02,0x10,0x00,0xF1,0x00,0x03,0x06,0x00,0xC8,0x00,0x00,0x00,0x00,0x56,0x95};

uint8_t l3[] = {0x03,0x10,0x00,0xF1,0x00,0x03,0x06,0x00,0xC8,0x45,0xBB,0x80,0x00,0x50,0xFD};
uint8_t m3[] = {0x03,0x10,0x00,0xF1,0x00,0x03,0x06,0x01,0xC8,0x45,0xBB,0x80,0x00,0x51,0x2C};
uint8_t n3[] = {0x03,0x10,0x00,0xF1,0x00,0x03,0x06,0x01,0xC8,0x00,0x00,0x00,0x00,0x55,0xC5};

uint8_t zero1[] = {0x01,0x10,0x00,0xF2,0x00,0x04,0x08,0x00,0xC8,0x17,0x70,0x00,0x00,0x00,0x00,0x07,0x9C};

uint8_t p_moder1[] = {0x01,0x06,0x00,0x62,0x00,0x00,0x28,0x14};
uint8_t p_moder2[] = {0x02,0x06,0x00,0x62,0x00,0x00,0x28,0x27};
uint8_t p_moder3[] = {0x03,0x06,0x00,0x62,0x00,0x00,0x29,0xF6};

uint8_t DS1[] = {0x01,0x06,0x00,0xFA,0x00,0x01,0x68,0x3B};
uint8_t DS2[] = {0x02,0x06,0x00,0xFA,0x00,0x01,0x68,0x08};
uint8_t DS3[] = {0x03,0x06,0x00,0xFA,0x00,0x01,0x69,0xD9};

uint8_t EN1[] = {0x01,0x06,0x00,0xFA,0x00,0x00,0xA9,0xFB};
uint8_t EN2[] = {0x02,0x06,0x00,0xFA,0x00,0x00,0xA9,0xC8};
uint8_t EN3[] = {0x03,0x06,0x00,0xFA,0x00,0x00,0xA8,0x19};

uint8_t CLR_FAULT1[] = {0x01,0x06,0x00,0xF8,0x00,0x01,0x39,0xFB};
uint8_t CLR_FAULT2[] = {0x02,0x06,0x00,0xFB,0x00,0x01,0x39,0xC8};
uint8_t CLR_FAULT3[] = {0x03,0x06,0x00,0xFB,0x00,0x01,0x38,0x19};

uint8_t CLR_POS1[] = {0x01,0x06,0x00,0xF8,0x00,0x01,0xC9,0xFB};
uint8_t CLR_POS2[] = {0x02,0x06,0x00,0xF8,0x00,0x01,0xC9,0xC8};
uint8_t CLR_POS3[] = {0x03,0x06,0x00,0xF8,0x00,0x01,0xC8,0x19};

uint8_t FeedbackData1[] = {0x01,0x04,0x00,0x31,0x00,0x14,0xA1,0xCA};
uint8_t FeedbackData2[] = {0x02,0x04,0x00,0x31,0x00,0x14,0xA1,0xF9};
uint8_t FeedbackData3[] = {0x03,0x04,0x00,0x31,0x00,0x14,0xA0,0x28};

bool i2c_read_bytes2(uint8_t reg_addr, uint8_t *p_data, uint32_t len);
enum os_period period = OS_0MS;

volatile uint8_t key_513_pressed;
volatile uint8_t key_311_pressed;
volatile uint8_t key_800_pressed;
volatile uint8_t key_906_pressed;
volatile uint8_t key_307_pressed;
volatile uint8_t key_804_pressed;
volatile uint8_t key_801_pressed;
volatile uint8_t key_908_pressed;
volatile uint8_t key_B06_pressed;
volatile uint8_t key_907_pressed;
volatile uint8_t key_909_pressed;

volatile uint8_t zero = 1;
uint8_t P[17];
uint8_t w2[17];
uint16_t BalanceCarTaskCount = 0;
volatile float s = 0;
volatile float e = 0;
volatile float j = 0;
volatile uint32_t y = 0;
uint8_t Period_5ms_Count = 0;
uint8_t Period_10ms_Count = 0;
uint8_t Period_20ms_Count = 0;
uint8_t Period_100ms_Count = 0;
uint8_t Period_1000ms_Count = 0;

_Bool Period_1ms_Expire_Flag = false;
_Bool Period_5ms_Expire_Flag = false;
_Bool Period_10ms_Expire_Flag = false;
_Bool Period_20ms_Expire_Flag = false;
_Bool Period_100ms_Expire_Flag = false;
_Bool Period_1000ms_Expire_Flag = false;

static void Task_1ms(void);
static void Task_5ms(void);
static void Task_10ms(void);
static void Task_20ms(void);
static void Task_100ms(void);
static void Task_1000ms(void);


void Os_Period(void) {
    BalanceCarTaskCount++;
    Period_1ms_Expire_Flag = true;

    switch(BalanceCarTaskCount) {
        case OS_5MS_a:
            Period_5ms_Expire_Flag = true;
            break;
        case OS_5MS_b:
            if(Period_10ms_Count >= 2) {
                Period_10ms_Expire_Flag = true;
                Period_10ms_Count = 0;
            } else {
                Period_10ms_Count++;
            }
            break;
        case OS_5MS_c:
            if(Period_20ms_Count >= 4) {
                Period_20ms_Expire_Flag = true;
                Period_20ms_Count = 0;
            } else {
                Period_20ms_Count++;
            }
            break;
        case OS_5MS_d:
            if(Period_100ms_Count >= 20) {
                Period_100ms_Expire_Flag = true;
                Period_100ms_Count = 0;
            } else {
                Period_100ms_Count++;
            }
            break;
        case OS_5MS_e:
            BalanceCarTaskCount = 0;
            if(Period_1000ms_Count >= 200) {
                Period_1000ms_Expire_Flag = true;
                Period_1000ms_Count = 0;
            } else {
                Period_1000ms_Count++;
            }
            break;
        default:
            break;
    }
}

void Os_Task(void) {
    if(Period_1ms_Expire_Flag) {
        Task_1ms();
        Period_1ms_Expire_Flag = false;
    }
    if(Period_5ms_Expire_Flag) {
        Task_5ms();
        Period_5ms_Expire_Flag = false;
    }
    if(Period_10ms_Expire_Flag) {
        Task_10ms();
        Period_10ms_Expire_Flag = false;
    }
    if(Period_20ms_Expire_Flag) {
        Task_20ms();
        Period_20ms_Expire_Flag = false;
    }
    if(Period_100ms_Expire_Flag) {
        Task_100ms();
        Period_100ms_Expire_Flag = false;
    }
    if(Period_1000ms_Expire_Flag) {
        Task_1000ms();
        Period_1000ms_Expire_Flag = false;
    }
}

static void Task_1ms(void) {
    void Task_1ams();
    //********************陀螺仪数据采集************************
    spi_imu_read_bytes(0x1F, test, 12);
    imu_read_data();
    imu_get_latest_data(&data);
    float tx = (float)imu_lowpass_filter(&data).accel_x;
    float ty = (float)imu_lowpass_filter(&data).accel_y;
    float tz = (float)imu_lowpass_filter(&data).accel_z;
    lll = atan2_deg(ty,tz);

    //********************陀螺仪数据采集************************

    // cvl = getAngle(2);
    // setPhaseVoltage(2, -4, 0, cvl*7);
    // motor_app_loop(1, 0);
//&&&&&&&&&&&
    // if (key_311_pressed == 1)
    // {   position_pid[1].Kp = 5;
    //     position_pid[1].Ki = 1;
    //     position_pid[1].Kd = 0.1;
    //     cvt = 0;
    // }
//&&&&&&&&&&&
    // motor_app_loop(1, cvt);
    // i2c_read_bytes(0x1F, test, 12);
    // imu_read_data();
    // imu_get_latest_data(&data);
    // velocityControlLoop(1 ,0, Sensor_AS5600_getVelocity(1,micros()),getAngle(1)*7,micros(),&speed_pid[1]);
    if (key_311_pressed == 0)
    {
        //
        // if (qqw == 0){
        //     R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);
        //     g_ioport.p_api->pinWrite(g_ioport.p_ctrl, BSP_IO_PORT_08_PIN_02, 1);
        //     R_BSP_SoftwareDelay(2000, BSP_DELAY_UNITS_MILLISECONDS);
        //     g_ioport.p_api->pinWrite(g_ioport.p_ctrl, BSP_IO_PORT_08_PIN_02, 0);
        //     qqw = 1;
        // }
        //

        if (ii != KeyScan(key_908_pressed)) {
            i++;
        }
        ii = KeyScan(key_908_pressed);

        //****************************这是用设置零点试滴************************************
        if (key_311_pressed == 0||zero == 0) {
            if (key_311_pressed == 0) {
                s = adc_buf[0]/65535*3.14;
                e = adc_buf[1]*2;
                j = (float)(adc_buf[2])/65535*300;
            }
            MIT_DBC_U1.Position = s/2;;
            MIT_DBC_U2.Position = -1*s/2;
            MIT_DBC_U3.Position = e*2*PI/65000;
            //
            AAADDD(1, 150-lll, sss, torqueBuf);
            g_uart1.p_api->write(g_uart1.p_ctrl, torqueBuf, 9);

            position_pid[1].Kp = 0;
            position_pid[1].Ki = 0;
            position_pid[1].Kd = 1;
            cvt =  getAngle(1);

            MIT_DBC_step(&MIT_DBC_U1, &MIT_DBC_Y1);
            MIT_DBC_step(&MIT_DBC_U2, &MIT_DBC_Y2);
            MIT_DBC_step(&MIT_DBC_U3, &MIT_DBC_Y3);
            R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);
            canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x202, MIT_DBC_Y1.Out1);
            R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);
            canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x203, MIT_DBC_Y2.Out1);
            R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);
            canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x204, MIT_DBC_Y3.Out1);
        }
    }
}

static void Task_5ms(void) {
    void Task_5ams();

    // motor_app_loop(2, 0);

    if (g_motor.enable.enable == 0&&key_311_pressed == 1&&zero == 1) {
        g_motor.position.position = 0;
        pack_position_command(&g_motor.position, (uint8_t*)&w1[0]);
        g_uart0.p_api->write(g_uart0.p_ctrl, w1,  pack_position_command(&g_motor.position, w1));
    }

}

static void Task_10ms(void) {
    void Task_10ams();
    //*******************************引脚电平检测*******************************
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_08_PIN_00, (bsp_io_level_t *)&key_800_pressed);
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_03_PIN_11, (bsp_io_level_t *)&key_311_pressed);
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_05_PIN_13, (bsp_io_level_t *)&key_513_pressed);
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_09_PIN_06, (bsp_io_level_t *)&key_906_pressed);
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_03_PIN_07, (bsp_io_level_t *)&key_307_pressed);
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_08_PIN_04, (bsp_io_level_t *)&key_804_pressed);
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_08_PIN_01, (bsp_io_level_t *)&key_801_pressed);
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_09_PIN_08, (bsp_io_level_t *)&key_908_pressed);
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_11_PIN_06, (bsp_io_level_t *)&key_B06_pressed);
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_09_PIN_07, (bsp_io_level_t *)&key_907_pressed);
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_09_PIN_09, (bsp_io_level_t *)&key_909_pressed);
    //*******************************引脚电平检测*******************************

}

static void Task_20ms(void) {
    void Task_20ams();
    //********************************这是用来使能关节电机滴************************************
        if (key_513_pressed == 0)
        {
            canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x003, a);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x002, a);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x004, a);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
        }
    //********************************这是用来使能关节电机滴************************************

    //********************************这是用来清除关节电机错误滴************************************
    if (key_800_pressed == 0)
    {
        canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x003, q);
        R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
        canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x002, q);
        R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
        canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x004, q);
        R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
    }
    //********************************这是用来清除关节电机错误滴************************************

    //********************************这是用设置零点试滴************************************

    if (key_311_pressed == 0||zero == 0) {
        // g_ioport.p_api->pinWrite(g_ioport.p_ctrl, BSP_IO_PORT_07_PIN_05, 1);
        // g_ioport.p_api->pinWrite(g_ioport.p_ctrl, BSP_IO_PORT_11_PIN_05, 1);
        zero = 0;
        R_ADC_B_Read(&g_adc0_ctrl, ADC_CHANNEL_0, &adc_buf[0]);
        R_ADC_B_Read(&g_adc0_ctrl, ADC_CHANNEL_1, &adc_buf[1]);
        R_ADC_B_Read(&g_adc0_ctrl, ADC_CHANNEL_2, &adc_buf[2]);
        // lu9685_servo_set(1, j);
        if (fabsf(getAngle(1))<=0.1&&adc_buf[1]<=100&&adc_buf[2]<=100&&key_311_pressed == 1) {
            canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x003, qq);
            canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x002, qq);
            canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x004, qq);
            MIT_DBC_U1.Position = 0;;
            MIT_DBC_U2.Position = 0;
            MIT_DBC_U3.Position = 0;
            MIT_DBC_step(&MIT_DBC_U1, &MIT_DBC_Y1);
            MIT_DBC_step(&MIT_DBC_U2, &MIT_DBC_Y2);
            MIT_DBC_step(&MIT_DBC_U3, &MIT_DBC_Y3);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x202, MIT_DBC_Y1.Out1);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x203, MIT_DBC_Y2.Out1);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x204, MIT_DBC_Y3.Out1);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);

            // Angle1.position = g_read_pos.position;
            // pack_home_command(&Angle1, &Angle11);
            // g_uart0.p_api->write(g_uart0.p_ctrl, &Angle11, 13);
            //
            // g_motor.position.position = 0;
            // uint8_t w1[17];
            // pack_position_command(&g_motor.position, w1);
            // g_uart0.p_api->write(g_uart0.p_ctrl, w1, 17);
            g_uart0.p_api->write(g_uart0.p_ctrl, CLR_FAULT1, 5);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            g_uart0.p_api->write(g_uart0.p_ctrl, DS1, 8);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            g_uart0.p_api->write(g_uart0.p_ctrl, EN1, 8);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            g_uart0.p_api->write(g_uart0.p_ctrl, p_moder1, 8);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            g_uart0.p_api->write(g_uart0.p_ctrl, CLR_POS1, 8);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);

            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            g_uart0.p_api->write(g_uart0.p_ctrl, DS2, 8);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            g_uart0.p_api->write(g_uart0.p_ctrl, EN2, 8);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            g_uart0.p_api->write(g_uart0.p_ctrl, p_moder2, 8);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            g_uart0.p_api->write(g_uart0.p_ctrl, CLR_POS2, 8);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);

            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            g_uart0.p_api->write(g_uart0.p_ctrl, DS3, 8);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            g_uart0.p_api->write(g_uart0.p_ctrl, EN3, 8);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            g_uart0.p_api->write(g_uart0.p_ctrl, p_moder3, 8);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
            g_uart0.p_api->write(g_uart0.p_ctrl, CLR_POS3, 8);
            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);

            R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);
            g_ioport.p_api->pinWrite(g_ioport.p_ctrl, BSP_IO_PORT_08_PIN_02, 1);
            R_BSP_SoftwareDelay(2000, BSP_DELAY_UNITS_MILLISECONDS);
            g_ioport.p_api->pinWrite(g_ioport.p_ctrl, BSP_IO_PORT_08_PIN_02, 0);

            // g_ioport.p_api->pinWrite(g_ioport.p_ctrl, BSP_IO_PORT_07_PIN_05, 0);
            // g_ioport.p_api->pinWrite(g_ioport.p_ctrl, BSP_IO_PORT_11_PIN_05, 0);
            zero = 1;
            qqw = 0;
        }
    }
    //********************************这是用设置零点试滴************************************

    //********************************这是用来失能系统滴************************************
    if (key_B06_pressed == 0)
    {
        MIT_DBC_U1.Position = 0;
        MIT_DBC_U1.Kp = 0;
        MIT_DBC_U1.Kd = 20;
        MIT_DBC_U1.Velocity = 0;
        MIT_DBC_U1.Torque = 0.5;

        MIT_DBC_U2.Position = 0;
        MIT_DBC_U2.Kp = 0;
        MIT_DBC_U2.Kd = 20;
        MIT_DBC_U2.Velocity = 0;
        MIT_DBC_U2.Torque = 0.5;

        MIT_DBC_step(&MIT_DBC_U1, &MIT_DBC_Y1);
        MIT_DBC_step(&MIT_DBC_U2, &MIT_DBC_Y2);

        R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
        canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x202, MIT_DBC_Y1.Out1);
        R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
        canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x203, MIT_DBC_Y2.Out1);
        R_BSP_SoftwareDelay(2000, BSP_DELAY_UNITS_MILLISECONDS);

        canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x004, u);
        R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);
        canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x003, u);
        R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);
        canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x002, u);
        R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);

        g_uart0.p_api->write(g_uart0.p_ctrl, DS1, 8);
        R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);

        g_uart0.p_api->write(g_uart0.p_ctrl, DS2, 8);
        R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);

        g_uart0.p_api->write(g_uart0.p_ctrl, DS3, 8);
        R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);

    }
    //********************************这是用来失能系统滴************************************
    //********************************这是用来使能步进电机滴************************************
    if (key_307_pressed == 0)
    {   R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);
        g_uart0.p_api->write(g_uart0.p_ctrl, CLR_FAULT1, 5);
        R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);
        g_uart0.p_api->write(g_uart0.p_ctrl, EN1, 8);
        R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);
        g_uart0.p_api->write(g_uart0.p_ctrl, CLR_FAULT2, 5);
        R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);
        g_uart0.p_api->write(g_uart0.p_ctrl, EN2, 8);
        R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);
        g_uart0.p_api->write(g_uart0.p_ctrl, CLR_FAULT3, 5);
        R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);
        g_uart0.p_api->write(g_uart0.p_ctrl, EN3, 8);

    }
    //********************************这是用来使步进电机能滴************************************

    //********************************这是用来失能步进电机滴************************************
    if (key_906_pressed == 0)
    {
        g_uart0.p_api->write(g_uart0.p_ctrl, DS1, 8);
        R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);

        g_uart0.p_api->write(g_uart0.p_ctrl, DS2, 8);
        R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);

        g_uart0.p_api->write(g_uart0.p_ctrl, DS3, 8);
        R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
    }
    //********************************这是用来失能步进电机滴************************************

    //********************************这是用来调试步进电机位置滴************************************
    if (key_311_pressed == 0||zero == 0) {
        // if ((i-qqq) != 0 && (i-qqq)%2 == 0 )
        // {
        //     p = p^1;
        //     qqq = i;
        // }
                if (key_804_pressed == 0 && (aaa == 0)) {
                    R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
                    g_uart0.p_api->write(g_uart0.p_ctrl, l3, 15);
                    R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
                    g_uart0.p_api->write(g_uart0.p_ctrl, l2, 15);
                    aaa = 1;
                    bbb = 0;
                    ccc = 0;
                }
                else if (key_801_pressed == 0 && (bbb == 0)) {
                    R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
                    g_uart0.p_api->write(g_uart0.p_ctrl, m3, 15);
                    R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
                    g_uart0.p_api->write(g_uart0.p_ctrl, m2, 15);
                    aaa = 0;
                    bbb = 1;
                    ccc = 0;

                }
                else if (ccc == 0&&key_804_pressed == 1 && key_801_pressed == 1){
                    R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
                    g_uart0.p_api->write(g_uart0.p_ctrl, n3, 15);
                    R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
                    g_uart0.p_api->write(g_uart0.p_ctrl, n2, 15);
                    aaa = 0;
                    bbb = 0;
                    ccc = 1;
                }
                else{
                    aaa = 0;
                    bbb = 0;
                }


                if (key_907_pressed == 0 && (aaa1 == 0)) {
                    R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
                            g_uart0.p_api->write(g_uart0.p_ctrl, l1, 15);
                            aaa1 = 1;
                            bbb1 = 0;
                            ccc1 = 0;

                        }
                        else if (key_909_pressed == 0 && (bbb1 == 0)) {
                            R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
                            g_uart0.p_api->write(g_uart0.p_ctrl, m1, 15);
                            aaa1 = 0;
                            bbb1 = 1;
                            ccc1 = 0;

                        }
                        else if (ccc1 == 0&&(key_909_pressed==1&&key_907_pressed == 1)) {
                            g_uart0.p_api->write(g_uart0.p_ctrl, n1, 15);
                            R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);
                            g_uart0.p_api->write(g_uart0.p_ctrl, n1, 15);

                            aaa1 = 0;
                            bbb1 = 0;
                            ccc1 = 1;

                        }
                        else {
                            aaa1 = 0;
                            bbb1 = 0;
                        }

            }

    //********************************这是用来调试步进电机位置滴************************************



}

static void Task_100ms(void) {
    void Task_100ams();
}

static void Task_1000ms(void) {
    void Task_1000ams();


}