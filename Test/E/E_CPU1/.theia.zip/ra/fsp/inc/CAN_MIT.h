//
// Created by Qw011 on 2026/6/20.
//

#ifndef E_CAN_MIT_H
#define E_CAN_MIT_H

#endif //E_CAN_MIT_H
#include "hal_data.h"



fsp_err_t canfd_send_test_data(can_ctrl_t * p_ctrl, uint32_t id, uint8_t * p_data);