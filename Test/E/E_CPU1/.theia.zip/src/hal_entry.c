#include "hal_data.h"
#include "CAN_MIT.h"
#include "MIT_DBC.h"
#include "S485.h"
#include "UVW.h"
#include "os.h"
#include "SysTick.h"
#include "key_proc.h"
#include "imu_system.h"
#include "circular_buffer.h"
#include "imu_i2c_driver.h"
#include "foc_lib.h"
#include "a.h"
#include "arm_kinematics.h"
#include "blueberry_tracker.h"

 void Task_1ams(void){};
 void Task_5ams(void){};
 void Task_10ams(void) {
     // 串口中断收到完整蓝莓帧标志
     // if (g_new_data_ready)
     // {
     //     g_new_data_ready = false;
     //     MotorIncrement_t action = Tracker_Process(
     //         &tracker,
     //         latest_targets1,
     //         latest_count1,
     //         0, 0, 0,
     //         670+(1000-670)*MIT_DBC_U3.Position/4/6.28
     //     );

         // Motor1_TargetAngle += action.m1_inc_rad;
         // Motor2_TargetAngle += action.m2_inc_deg;
         // Motor3_TargetAngle += action.m3_inc_deg;
         // Motor4_TargetAngle += action.m4_inc_rad;
         // Motor_Output();

         // 追踪状态到达采摘位，执行夹爪/剪刀动作
 //         if (tracker.state == STATE_PICKING)
 //         {
 //
 //         }
 //     }
 };
 void Task_20ams(void){};
 void Task_100ams(void){};
 void Task_1000ams(void){};

motor_position_t motor_position;
uint8_t buffer[];
uint8_t moveBuf[];
uint8_t qr[] = {0x00, 0xFB,0xFB,0x00, 0xFB,0xFB,0x00, 0xFB};
#if (1 == BSP_MULTICORE_PROJECT) && BSP_TZ_SECURE_BUILD
bsp_ipc_semaphore_handle_t g_core_start_semaphore =
{
    .semaphore_num = 0
};
#endif

//*************************************小核向大核发送函数**************************************
__attribute__((section(".ram_noinit_nocache")))
static void send_msg(uint8_t reg_id, uint32_t data)
{
    uint32_t packed = ((uint32_t)reg_id << 24) | (data & 0x00FFFFFF);
    R_IPC_MessageSend(&g_ipc1_ctrl, packed);
}
//*************************************小核向大核发送函数**************************************

//*****************************小核接收大核中断回调函数，想干嘛在switch中添加case就OK了**************************************
void g_ipc0_callback(ipc_callback_args_t *p_args)
{
    uint32_t packed = p_args->message;
    uint8_t  reg_id = (packed >> 24) & 0xFF;
    uint32_t data   = packed & 0x00FFFFFF;
    switch (reg_id)
    {
        case 0x01:

            break;
        case 0x02:

            break;
        case 0x03:

            break;
        default:

            break;
    }
}
//*****************************小核接收大核中断回调函数，想干嘛在switch中添加**************************************

uint8_t EN[8];

motor_state motor1 = {
    .add = 1,
    .steering = 0,
    .Brake = 1,
    .speed = 0.5f
};
motor_state motor2 = {
    .add = 2,
    .steering = 0,
    .Brake = 1,
    .speed = 0.5f
};
motor_state motor3 = {
    .add = 3,
    .steering = 0,
    .Brake = 1,
    .speed = 0.5f
};
motor_state motor4 = {
    .add = 4,
    .steering = 0,
    .Brake = 1,
    .speed = 0.5f
};

uint16_t l;
#include "r_i2c_master_api.h"
//这是中断标志位，我调试用的******
volatile bool i2c_tx_complete = false;
volatile bool i2c_rx_complete = false;
volatile bool i2c1_tx_complete = false;
volatile bool i2c1_rx_complete = false;
volatile bool i2c2_tx_complete = false;
volatile bool i2c2_rx_complete = false;

volatile bool xxxa = true;
volatile bool xxx1 = true;
volatile bool xxx2 = true;
//这是imu(就是陀螺仪)C通讯中断回调函数，用来清除标志位的，配合后面通讯收发用的
void sci_b_spi_callback(spi_callback_args_t *p_args)
{
    if (SPI_EVENT_TRANSFER_COMPLETE == p_args->event)
    {
        spi_transfer_complete = true;
    }
}
void sci_b_i2c_master_callback4(i2c_master_callback_args_t * p_args){
    if (p_args->event == I2C_MASTER_EVENT_TX_COMPLETE) {

        i2c1_tx_complete = true;
    } else if (p_args->event == I2C_MASTER_EVENT_RX_COMPLETE) {

        i2c1_rx_complete = true;
    } else if (p_args->event == I2C_MASTER_EVENT_ABORTED) {
        xxx1 = false;
    }
     else if (p_args->event == I2C_MASTER_EVENT_START) {
    }
     else{}

}
void sci_b_i2c_master_callback5(i2c_master_callback_args_t *p_args)
{if (p_args->event == I2C_MASTER_EVENT_TX_COMPLETE) {

    i2c2_tx_complete = true;
} else if (p_args->event == I2C_MASTER_EVENT_RX_COMPLETE) {

    i2c2_rx_complete = true;
} else if (p_args->event == I2C_MASTER_EVENT_ABORTED) {
    xxx2= false;
}
}

void uart1_blueberry_callback (uart_callback_args_t *p_args)
{
    // if (NULL == p_args) return;

    switch (p_args->event)
    {
        case UART_EVENT_TX_COMPLETE:
            break;
        case UART_EVENT_RX_COMPLETE:
                if (parse_blueberry_packet(rx_byte, latest_targets1, &latest_count1))
                {
                    g_new_data_ready = true;


            }
            g_uart1.p_api->read(g_uart1.p_ctrl,&rx_byte,1);
        case UART_EVENT_ERR_PARITY:
        case UART_EVENT_ERR_FRAMING:
        case UART_EVENT_ERR_OVERFLOW:
            break;
        default:
            break;
    }
}


/*******************************************************************************************************************//**
 * main() is generated by the RA Configuration editor and is used to generate threads if an RTOS is used.  This function
 * is called by main() when no RTOS is used.
 **********************************************************************************************************************/
void hal_entry(void)
{
    /* TODO: add your own code here */
    SystickInit1();
    adc_status_t adc_sta;
    /* Wake up 2nd core if this is first core and we are inside a multicore project. */
#if (0 == _RA_CORE) && (1 == BSP_MULTICORE_PROJECT) && !BSP_TZ_NONSECURE_BUILD

#if BSP_TZ_SECURE_BUILD
    /* Take semaphore so 2nd core can clear it */
    R_BSP_IpcSemaphoreTake(&g_core_start_semaphore);
#endif

    R_BSP_SecondaryCoreStart();

#if BSP_TZ_SECURE_BUILD
    /* Wait for 2nd core to start and clear semaphore */
    while(FSP_ERR_IN_USE == R_BSP_IpcSemaphoreTake(&g_core_start_semaphore))
    {
        ;
    }
#endif
#endif


    R_IPC_Open(&g_ipc0_ctrl, &g_ipc0_cfg);
    R_IPC_Open(&g_ipc1_ctrl, &g_ipc1_cfg);


    g_uart0.p_api->open(g_uart0.p_ctrl, g_uart0.p_cfg);
    g_uart1.p_api->open(g_uart1.p_ctrl, g_uart1.p_cfg);
    g_ioport.p_api->open(g_ioport.p_ctrl, g_ioport.p_cfg);

    R_BSP_PinWrite(BSP_IO_PORT_08_PIN_10 , 0);

    R_SCI_B_UART_Read(g_uart0.p_ctrl, uart_rx_byte, 1);
    //================ ADC初始化 ====================
    R_ADC_B_Open(&g_adc0_ctrl, &g_adc0_cfg);
    R_ADC_B_ScanCfg(&g_adc0_ctrl, &g_adc0_scan_cfg);
    R_ADC_B_Calibrate(&g_adc0_ctrl, NULL);
    do {
        R_ADC_B_StatusGet(&g_adc0_ctrl, &adc_sta);
    } while (adc_sta.state == ADC_STATE_CALIBRATION_IN_PROGRESS);
    R_ADC_B_ScanStart(&g_adc0_ctrl);
    //================ 初始化完成 ====================

    R_GPT_Open(&g_timer1_ctrl, &g_timer1_cfg);
    R_GPT_Start(&g_timer1_ctrl);
    R_GPT_Open(&g_timer2_ctrl, &g_timer2_cfg);
    R_GPT_Start(&g_timer2_ctrl);
    R_GPT_Open(&g_timer3_ctrl, &g_timer3_cfg);
    R_GPT_Start(&g_timer3_ctrl);
    motor_app_init();

    R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);
    MIT_DBC_initialize();
    R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);
    g_canfd0.p_api->open(g_canfd0.p_ctrl, g_canfd0.p_cfg);
    R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);
    g_i2c4.p_api->open(g_i2c4.p_ctrl, g_i2c4.p_cfg);
    g_i2c5.p_api->open(g_i2c5.p_ctrl, g_i2c5.p_cfg);

    R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);
    g_uart0.p_api->write(g_uart0.p_ctrl, EN, 8);
    //************SPI**********************
    // fsp_err_t err1;
    // // 初始化SPI8
    // err1 = g_sci_spi8.p_api->open(g_sci_spi8.p_ctrl, &g_sci_spi8_cfg);
    // if(FSP_SUCCESS != err1)
    // {
    //     while(1);
    // }
    // // 绑定传输完成回调
    // g_sci_spi8.p_api->callbackSet(g_sci_spi8.p_ctrl, sci_b_spi_callback, NULL, NULL);
    //************SPI**********************

    // imu_system_init();
    // circular_buffer_init(&g_imu_system.buffer);
    // AAADDD(0x01, 0, torqueBuf, moveBuf);
    // g_uart0.p_api->write(g_uart0.p_ctrl, torqueBuf, 8);
    // g_ioport.p_api->pinWrite(g_ioport.p_ctrl, BSP_IO_PORT_08_PIN_10, 1);
    g_uart1.p_api->read(g_uart1.p_ctrl,&rx_byte,1);
    // ArmController_Init(&arm_ctrl, 0.5f, 0.01f, 0.1f, 1.2f, 100.0f);
    // Tracker_Init(&tracker, &arm_ctrl);
    while (1) {
        // MIT_DBC_step();
        // R_GPT_InfoGet(&g_timer1_ctrl, &info);
        // R_GPT_DutyCycleSet(&g_timer1_ctrl, (uint32_t)(50 * info.period_counts / 100), GPT_IO_PIN_GTIOCA);
        // canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x201,MIT_DBC_Y.Out1);
        // R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);

        // send_msg(0x01,0x01);
        // motor_control(&motor1);
        // R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MILLISECONDS);
        // motor_control(&motor2);
        // R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MILLISECONDS);
        // motor_control(&motor3);
        // R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MILLISECONDS);
        // motor_control(&motor4);
        // R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MILLISECONDS);
        //

        Os_Task();
        // MIT_DBC_U1.Position = 0;;
        //
        // MIT_DBC_step(&MIT_DBC_U1, &MIT_DBC_Y1);
        //
        // R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
        // canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x202, MIT_DBC_Y1.Out1);


    //     MIT_DBC_U1.Position = 0;;
    //     MIT_DBC_U2.Position = 0;
    //     MIT_DBC_U3.Position = 0;
    //     MIT_DBC_step(&MIT_DBC_U1, &MIT_DBC_Y1);
    //     MIT_DBC_step(&MIT_DBC_U2, &MIT_DBC_Y2);
    //     MIT_DBC_step(&MIT_DBC_U3, &MIT_DBC_Y3);
    //     R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
    //     canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x202, MIT_DBC_Y1.Out1);
    //     R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
    //     canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x203, MIT_DBC_Y2.Out1);
    //     R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
    //     canfd_send_test_data((can_ctrl_t *)&g_canfd0_ctrl, 0x204, MIT_DBC_Y3.Out1);
    //     R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_MILLISECONDS);
    //
    //     motor_position.address=0;
    //     motor_position.position=0;
    //     pack_position_command(&motor_position, 0);
    //     g_uart0.p_api->write(g_uart0.p_ctrl, buffer, 15);
    //
    //     motor_position.address=0x01;
    //     motor_position.position=0;
    //     pack_position_command(&motor_position, 0);
    //     g_uart0.p_api->write(g_uart0.p_ctrl, buffer, 15);
    //
    //     motor_position.address=0x02;
    //     motor_position.position=0;
    //     pack_position_command(&motor_position, 0);
    //     g_uart0.p_api->write(g_uart0.p_ctrl, buffer, 15);

    //
    }

#if (1 == _RA_CORE) && (1 == BSP_MULTICORE_PROJECT) && BSP_TZ_SECURE_BUILD
    /* Signal to 1st core that 2nd core has started */
    R_BSP_IpcSemaphoreGive(&g_core_start_semaphore);
#endif


#if BSP_TZ_SECURE_BUILD
    /* Enter non-secure code */
    R_BSP_NonSecureEnter();
#endif
}

#if BSP_TZ_SECURE_BUILD

FSP_CPP_HEADER
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ();

/* Trustzone Secure Projects require at least one nonsecure callable function in order to build (Remove this if it is not required to build). */
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ()
{

}
FSP_CPP_FOOTER

#endif
void sci_i2c_txi_isr(void);
void sci_i2c_tei_isr(void);
#if SCI_I2C_CFG_DTC_ENABLE
void sci_i2c_rxi_isr(void);
#endif

const void *dummy_sci_i2c_isr_array[] = {
    sci_i2c_txi_isr,
    sci_i2c_tei_isr,
#if SCI_I2C_CFG_DTC_ENABLE
    sci_i2c_rxi_isr,
#endif
    (void *)0
};
